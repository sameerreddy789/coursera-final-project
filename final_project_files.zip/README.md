# Simple Interest Calculator

This is a basic Bash script to calculate Simple Interest based on user input.

## 📜 Usage
Run the following command in your terminal:
```bash
bash simple-interest.sh
```

## 📁 Files in This Repo
- `simple-interest.sh` - Shell script to calculate simple interest
- `LICENSE` - Apache 2.0 License
- `README.md` - Project overview and instructions
- `CODE_OF_CONDUCT.md` - Code of conduct for contributors
- `CONTRIBUTING.md` - Contribution guidelines

## 👤 Author
Vedium Sameer Reddy  
[GitHub Profile](https://github.com/yourusername)
